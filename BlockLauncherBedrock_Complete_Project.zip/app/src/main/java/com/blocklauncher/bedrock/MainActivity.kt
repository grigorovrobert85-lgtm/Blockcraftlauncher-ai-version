package com.blocklauncher.bedrock

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView
import android.widget.Toast

private const val GAME_PACKAGE = "com.mojang.minecraftpe"
private const val PICK_APK = 210
private const val PICK_PACK = 211

class MainActivity : Activity() {
    private val bg = Color.rgb(23, 23, 23)
    private val panel = Color.rgb(37, 37, 37)
    private val surface = Color.rgb(48, 48, 48)
    private val surfaceLight = Color.rgb(58, 58, 58)
    private val green = Color.rgb(112, 177, 57)
    private val greenDark = Color.rgb(75, 126, 39)
    private val textMain = Color.rgb(244, 244, 244)
    private val textMuted = Color.rgb(173, 173, 173)
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("launcher_prefs", MODE_PRIVATE) }
    private var installedVersion: String? = null

    // Historical release labels are catalog entries, not bundled APK files.
    private val versions = listOf(
        "26.60", "26.52", "26.51", "26.50", "26.45", "26.44", "26.43", "26.42", "26.41",
        "26.40", "26.35", "26.34", "26.33", "26.32", "26.31", "26.30", "26.23", "26.22",
        "26.21", "26.20", "26.13", "26.12", "26.11", "26.10", "26.3", "26.2", "26.1", "26.0",
        "1.21.132", "1.21.131", "1.21.130", "1.21.124", "1.21.123", "1.21.122", "1.21.121",
        "1.21.120", "1.21.114", "1.21.113", "1.21.112", "1.21.111", "1.21.101", "1.21.100",
        "1.21.94", "1.21.93", "1.21.92", "1.21.91", "1.21.90", "1.21.84", "1.21.82",
        "1.21.81", "1.21.80", "1.21.73", "1.21.72", "1.21.71", "1.21.70", "1.21.62",
        "1.21.61", "1.21.60", "1.21.51", "1.21.50", "1.21.44", "1.21.43", "1.21.42",
        "1.21.41", "1.21.40", "1.21.31", "1.21.30", "1.21.23", "1.21.22", "1.21.21",
        "1.21.20", "1.21.3", "1.21.2", "1.21.1", "1.21.0", "1.20.81", "1.20.80", "1.20.73",
        "1.20.72", "1.20.71", "1.20.70", "1.20.62", "1.20.60", "1.20.51", "1.20.50",
        "1.20.41", "1.20.40", "1.20.32", "1.20.31", "1.20.30", "1.20.15", "1.20.14",
        "1.20.13", "1.20.12", "1.20.10", "1.20.1", "1.20.0", "1.19.83", "1.19.81",
        "1.19.80", "1.19.73", "1.19.72", "1.19.71", "1.19.70", "1.19.63", "1.19.62", "1.19.60"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        installedVersion = readInstalledVersion()
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int = 6): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun label(value: String, size: Float = 14f, color: Int = textMain, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
            includeFontPadding = true
        }

    private fun actionButton(value: String, primary: Boolean = false, action: () -> Unit): Button =
        Button(this).apply {
            text = value
            isAllCaps = false
            textSize = 14f
            minHeight = dp(44)
            setTextColor(if (primary) Color.WHITE else textMain)
            background = shape(if (primary) greenDark else surfaceLight, 5)
            setPadding(dp(12), dp(5), dp(12), dp(5))
            stateListAnimator = null
            setOnClickListener { action() }
        }

    private fun gap(height: Int): View = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun sectionCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(13), dp(14), dp(13))
        background = shape(panel, 5)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) }
    }

    private fun pixelStrip(): View = object : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val block = dp(12).coerceAtLeast(8).toFloat()
            val colors = intArrayOf(greenDark, green, Color.rgb(89, 145, 43), Color.rgb(57, 98, 32))
            var x = 0f
            var i = 0
            while (x < width) {
                paint.color = colors[i % colors.size]
                canvas.drawRect(x, 0f, x + block, height.toFloat(), paint)
                x += block
                i++
            }
        }
    }.apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(5)) }

    private fun shell(title: String, subtitle: String, tab: Int) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(10))
            setBackgroundColor(Color.rgb(29, 29, 29))
        }
        val logoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = label("MINECRAFT", 23f, textMain, true).apply {
            letterSpacing = 0.04f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }
        logoRow.addView(logo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        logoRow.addView(label("BEDROCK", 11f, green, true))
        header.addView(logoRow)
        header.addView(gap(2))
        header.addView(label(title.uppercase(), 13f, textMuted, true))
        header.addView(label(subtitle, 12f, textMuted))
        root.addView(header)
        root.addView(pixelStrip())

        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(12))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            setBackgroundColor(Color.rgb(30, 30, 30))
        }
        val navItems = listOf("Игра", "Версии", "Файлы", "Настройки")
        navItems.forEachIndexed { index, text ->
            val b = TextView(this).apply {
                this.text = text
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (index == tab) Color.WHITE else textMuted)
                background = shape(if (index == tab) greenDark else Color.TRANSPARENT, 4)
                setPadding(dp(2), dp(12), dp(2), dp(12))
                setOnClickListener {
                    when (index) {
                        0 -> showHome()
                        1 -> showVersions()
                        2 -> showFiles()
                        else -> showSettings()
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(4) })
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showHome() {
        installedVersion = readInstalledVersion()
        shell("Главная", "Запуск игры и состояние устройства", 0)

        val play = sectionCard()
        play.addView(label("BEDROCK EDITION  /  ANDROID", 11f, green, true))
        play.addView(gap(8))
        play.addView(label("Готов к игре?", 24f, textMain, true))
        play.addView(gap(4))
        play.addView(label("Запускается версия Minecraft, которая сейчас установлена на телефоне.", 13f, textMuted))
        play.addView(gap(13))
        play.addView(actionButton("▶   ИГРАТЬ", true) { launchMinecraft() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        play.addView(gap(8))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(actionButton("Каталог версий") { showVersions() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        quick.addView(actionButton("Импорт файла") { showFiles() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        play.addView(quick)
        content.addView(play)

        val status = sectionCard()
        status.addView(label("УСТАНОВЛЕННАЯ ИГРА", 11f, textMuted, true))
        status.addView(gap(7))
        val found = installedVersion != null
        status.addView(label(if (found) "● Minecraft найден" else "● Minecraft не найден", 17f, if (found) green else Color.rgb(239, 180, 75), true))
        status.addView(gap(5))
        status.addView(label(if (found) "Версия приложения: ${installedVersion}" else "Установи официальную Minecraft Bedrock из своего магазина приложений.", 13f, textMuted))
        if (!found) {
            status.addView(gap(9))
            status.addView(actionButton("Открыть страницу Minecraft") { openUrl("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe") })
        }
        content.addView(status)

        val selected = prefs.getString("selected_version", versions.first()) ?: versions.first()
        val versionCard = sectionCard()
        versionCard.addView(label("ВЫБРАНО В КАТАЛОГЕ", 11f, textMuted, true))
        versionCard.addView(gap(5))
        versionCard.addView(label("Minecraft Bedrock $selected", 18f, textMain, true))
        versionCard.addView(gap(4))
        versionCard.addView(label("Это сохранённый пункт каталога, а не переключатель установленного APK.", 12f, textMuted))
        content.addView(versionCard)

        val tip = sectionCard()
        tip.addView(label("Примечание", 15f, textMain, true))
        tip.addView(gap(5))
        tip.addView(label("Лаунчер не содержит Minecraft. Он не показывает фиктивный FPS и не обещает менять дальность прорисовки извне: эти параметры настраиваются в самой игре.", 13f, textMuted))
        content.addView(tip)
    }

    private fun launchMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
        if (intent == null) {
            Toast.makeText(this, "Minecraft Bedrock не найдена. Установи игру отдельно.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Android не смог открыть Minecraft.", Toast.LENGTH_LONG).show()
        }
    }

    private fun readInstalledVersion(): String? {
        return try {
            val pInfo = if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getPackageInfo(GAME_PACKAGE, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(GAME_PACKAGE, 0)
            }
            pInfo.versionName ?: "установлена (номер версии не выдан)"
        } catch (_: Exception) { null }
    }

    private fun showVersions() {
        shell("Каталог версий", "Поиск по истории Bedrock", 1)
        val note = sectionCard()
        note.addView(label("${versions.size} пунктов каталога", 17f, textMain, true))
        note.addView(gap(5))
        note.addView(label("Внимание: выбор версии только сохраняет её в лаунчере. Чтобы запустить другую сборку, она должна быть установлена отдельно; каталог не содержит игровые APK.", 12f, textMuted))
        note.addView(gap(8))
        note.addView(actionButton("Официальные журналы изменений") { openUrl("https://feedback.minecraft.net/hc/en-us/sections/360001186971-Release-Changelogs") })
        content.addView(note)

        val search = EditText(this).apply {
            hint = "Найти версию, например 1.21.80"
            setHintTextColor(textMuted)
            setTextColor(textMain)
            textSize = 14f
            singleLine = true
            setPadding(dp(12), dp(3), dp(12), dp(3))
            background = shape(surface, 5)
        }
        content.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(10) })

        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(rows)

        fun renderRows(query: String) {
            rows.removeAllViews()
            val filtered = versions.filter { it.contains(query.trim(), ignoreCase = true) }
            if (filtered.isEmpty()) {
                rows.addView(label("Ничего не найдено.", 14f, textMuted))
                return
            }
            val selected = prefs.getString("selected_version", versions.first()) ?: versions.first()
            filtered.forEach { v ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(8), dp(8), dp(8))
                    background = shape(if (v == selected) Color.rgb(42, 59, 34) else panel, 4)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(5) }
                }
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(label(v, 16f, textMain, true))
                info.addView(label(if (v == selected) "Выбрана в каталоге" else if (v.startsWith("26.")) "Ветка 26.x" else "Исторический релиз", 11f, if (v == selected) green else textMuted))
                row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val b = actionButton(if (v == selected) "Выбрана" else "Выбрать", v == selected) {
                    prefs.edit().putString("selected_version", v).apply()
                    Toast.makeText(this, "В каталоге выбрана $v. Версия установленной игры не изменилась.", Toast.LENGTH_LONG).show()
                    renderRows(search.text?.toString() ?: "")
                }
                row.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)))
                rows.addView(row)
            }
        }
        renderRows("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderRows(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun showFiles() {
        shell("Файлы", "Паки, скины и пользовательские APK", 2)
        val packs = sectionCard()
        packs.addView(label("Ресурспаки и скины", 18f, textMain, true))
        packs.addView(gap(5))
        packs.addView(label("Выбери .mcpack, .mcaddon или .mcworld, чтобы передать файл совместимому приложению. PNG сохранённого скина открывается через доступные приложения; иногда импорт нужно закончить внутри Minecraft.", 13f, textMuted))
        packs.addView(gap(10))
        packs.addView(actionButton("Выбрать .mcpack / .mcaddon / .mcworld / PNG", true) { pickDocument(PICK_PACK) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        content.addView(packs)

        val apk = sectionCard()
        apk.addView(label("Установить свою версию APK", 18f, textMain, true))
        apk.addView(gap(5))
        apk.addView(label("Выбери Minecraft APK, который получил самостоятельно. Откроется системный установщик Android; лаунчер не снимает ограничения подписи и не обходит запрет на понижение версии. Установка может заменить текущую игру.", 13f, textMuted))
        apk.addView(gap(10))
        apk.addView(actionButton("Выбрать APK для установки", true) { pickDocument(PICK_APK) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        apk.addView(gap(6))
        apk.addView(label("Перед установкой другой сборки сделай резервную копию миров.", 12f, Color.rgb(239, 180, 75)))
        content.addView(apk)

        val help = sectionCard()
        help.addView(label("Если пак не открылся", 16f, textMain, true))
        help.addView(gap(5))
        help.addView(label("Открой Minecraft вручную и попробуй импорт из приложения «Файлы». В Android путь импорта и доступность старых версий зависят от установленной сборки и системных ограничений.", 13f, textMuted))
        content.addView(help)
    }

    private fun pickDocument(code: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.android.package-archive",
                "application/zip", "application/octet-stream", "image/png"
            ))
        }
        try {
            startActivityForResult(intent, code)
        } catch (_: Exception) {
            Toast.makeText(this, "Не получилось открыть выбор файлов.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Uses startActivityForResult for wide Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        val name = queryName(uri) ?: ""
        val lower = name.lowercase()
        if (requestCode == PICK_APK) {
            if (!lower.endsWith(".apk")) {
                Toast.makeText(this, "Выбери файл с расширением .apk.", Toast.LENGTH_LONG).show()
                return
            }
            installUserApk(uri)
        } else if (requestCode == PICK_PACK) {
            openPack(uri, lower)
        }
    }

    private fun installUserApk(uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Разреши установку для Block Launcher и снова выбери APK.", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось открыть настройки разрешения установки.", Toast.LENGTH_LONG).show()
            }
            return
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось открыть системный установщик. Проверь APK-файл.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openPack(uri: Uri, filename: String) {
        val mime = when {
            filename.endsWith(".png") -> "image/png"
            filename.endsWith(".mcpack") || filename.endsWith(".mcaddon") || filename.endsWith(".mcworld") -> "application/zip"
            else -> contentResolver.getType(uri) ?: "application/octet-stream"
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Открыть файл"))
        } catch (_: Exception) {
            Toast.makeText(this, "Нет приложения, которое может открыть этот файл. Попробуй выбрать его из приложения «Файлы» в Minecraft.", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else null
            }
        } catch (_: Exception) { null }
    }

    private fun showSettings() {
        shell("Настройки", "Системные параметры и информация", 3)
        val game = sectionCard()
        game.addView(label("Настройки Minecraft", 18f, textMain, true))
        game.addView(gap(5))
        game.addView(label("Перейти к системным сведениям о Minecraft: разрешения, память и доступные системные настройки.", 13f, textMuted))
        game.addView(gap(10))
        game.addView(actionButton("Открыть сведения о Minecraft", true) { openGameAppInfo() })
        content.addView(game)

        val limits = sectionCard()
        limits.addView(label("Почему здесь нет ползунка FPS?", 16f, textMain, true))
        limits.addView(gap(5))
        limits.addView(label("Стороннее Android-приложение не получает прямой доступ к игровому рендеру и приватным настройкам Minecraft. Чтобы изменить дальность прорисовки, графику и ограничения FPS, открой настройки внутри самой игры. Лаунчер не будет притворяться, что неработающие переключатели что-то меняют.", 13f, textMuted))
        limits.addView(gap(10))
        limits.addView(actionButton("Запустить Minecraft") { launchMinecraft() })
        content.addView(limits)

        val info = sectionCard()
        info.addView(label("Block Launcher", 16f, textMain, true))
        info.addView(gap(4))
        info.addView(label("Версия приложения: 1.0.0\nКаталог релизов: ${versions.size}\nMinecraft не входит в этот APK.", 13f, textMuted))
        info.addView(gap(9))
        info.addView(actionButton("Официальные журналы версий") { openUrl("https://feedback.minecraft.net/hc/en-us/sections/360001186971-Release-Changelogs") })
        content.addView(info)
    }

    private fun openGameAppInfo() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$GAME_PACKAGE")))
        } catch (_: Exception) {
            Toast.makeText(this, "Minecraft не найдена в настройках устройства.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось открыть ссылку.", Toast.LENGTH_LONG).show()
        }
    }
}
